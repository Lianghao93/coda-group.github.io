/********************************************************************************************************/
/*                                                                                                      */
/*  Author:     Ke Li <keli.genius@gmail.com>                                                           */
/*  Reference:  Ke Li, Jinhua Zheng, Miqing Li, Cong Zhou, Hui Lv, �A Novel Slicing Based Algorithm     */
/*              to Calculate Hypervolume for Multi-Objective Optimization Problems�, ICIC Express       */
/*              Letters: An International Journal of Research and Surveys, 4(4): 1113-1120, 2010.       */
/*                                                                                                      */
/********************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "global.h"
#include "rand.h"

const double reference[] = {2, 2, 2};

int dimension = 3;
int noNondom;

void main()
{
	FILE *fpt1;
	FILE *fpt2;

	int i, j;
	int sizeFront, noObjectives;
	long start, end;

	double hypervolume;
	double **front;
	double run_time;
	
	noNondom = 0;
	noObjectives = 5;
	hypervolume = 0;

	srand ((unsigned) time (NULL));
	rand ();
	seed = (rand () % 1000) / 1000.0;

	fpt1 = fopen ("SolutionSet.txt", "r");
    fpt2 = fopen ("results.txt", "a");
	
    sizeFront = ReadFile (&front, fpt1, noObjectives);
    for (i = 0; i < sizeFront; i++)
    {
        for (j = 0; j < noObjectives; j++)
            printf ("%lf\t", front[i][j]);
        printf ("\n");
    }
    if (noObjectives < 3)
        hypervolume = CalculateArea_2D (front, sizeFront, noObjectives);
    else
    {
        start = clock ();
        randomize ();
        
        hypervolume = CalculateHypervolume (front, sizeFront, noObjectives);
    }
    end = clock ();
    run_time = (double)(end - start) / CLOCKS_PER_SEC;
    
    printf ("\aProcess tatally %d points!\n", sizeFront);
    printf ("The running time of this program is: %lf\n", run_time);
    printf ("The hypervolume of this set is: %lf\n", hypervolume);
    fprintf (fpt2, "%lf\n", hypervolume);
    printf ("\n%d\n", noNondom);

	fflush (stdout);
	fflush (fpt1);
	fflush (fpt2);
	fclose (fpt1);
	fclose (fpt2);
	Deallocate_memrory (front, sizeFront);
}