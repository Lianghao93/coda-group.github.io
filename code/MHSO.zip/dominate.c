#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

/************************************************************************/
/*  If point1 dominates point2 then return 1							*/
/*  If point2 dominates point1 then return -1							*/
/*  If point1 is non-dominated  to point2 then return 0                  */ 
/************************************************************************/
int Dominates(double *point1, double *point2, int noObjectives)
{
	int  i;
	int  flag1, flag2;
	
	flag1 = 0;
	flag2 = 0;
	
	for (i = 0; i < noObjectives; i++)
	{
	  if (point1[i] <= point2[i])
		  flag1 = 1;
	  else
		  flag2 = 1;
	}
	if (flag1 == 1 && flag2 == 0)
	  return 1;
	else if (flag1 == 0 && flag2 == 1)
	  return -1;
	else
	  return 0;
} /* Dominates */

// If point 1 is dominated by the other points in the set at the first 'objective' dimension, return 1, else return 0
int Check_Dominate (double *front[], int noPoints, int objective)
{
	int i, flag;
	int n;
	
	flag = 0;
	n = noPoints;

	for (i = 1; i < n; i++)
	{
		if (Dominates (front[i], front[0], objective) == 1)
		{
			flag = 1;
			break;
		}
		else
			flag = 0;
	}
	
	return flag;
}