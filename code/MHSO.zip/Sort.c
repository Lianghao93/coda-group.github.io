#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

/* sort noPoints points in descending order at objective dimension */
void Sort (double *front[], int noPoints, int objective)
{
	int n;

	n = noPoints;
	Merge_Sort (front, 0, noPoints - 1, objective);
}

static void Merge (double *front[], int p, int q, int r, int objectives)
{
    int i, k;
    int begin1, end1, begin2, end2;
	
	double **temp;
   
	begin1 = p;    
	end1 = q;
    begin2 = q+1;  
	end2 = r;
	
	allocate_memory (&temp, (r - p + 1));

    k = 0;
    while ((begin1 <= end1)&&( begin2 <= end2))
    {
        if (front[begin1][objectives - 1] > front[begin2][objectives - 1])
        {
			copy (temp, front, k, begin1);
			begin1++; 
        }
        else
        {
			copy (temp, front, k, begin2);
            begin2++;
        }
        k++;            
    }
    
    while (begin1 <= end1) 
	{
		copy (temp, front, k, begin1);
		k++;
		begin1++;
	}
	while (begin2 <= end2)
	{
		copy (temp, front, k, begin2);
		k++;
		begin2++;
	}
    
	for (i = 0; i < (r - p +1); i++) 
        copy (front, temp, p + i, i);
	
	Deallocate_memrory (temp, (r - p + 1));
}


void Merge_Sort(double *front[], int p, int r, int objectives)
{
	int q;
	int n;

	n = objectives;

	if (p < r)
	{
		q = (p + r) / 2;

		Merge_Sort(front, p, q, n);
		Merge_Sort(front, q + 1, r, n);
		Merge(front, p, q, r, n);
	}
}