#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"


// Calculate the hypervolume of 'noPoints' with 'noObjectives'
double CalculateHypervolume(double *front[], int noPoints, int noObjectives)
{
	int n;
	int slice_number;			// it is used to record the total number of slices

	double volume;
	double *slice_depth;		// this array is used to record the slice depth of the current sliced slices

	volume = 0;
	n = noPoints;
	slice_number = 0;

	// this array used to store every depth of slice
	slice_depth = (double *)malloc(n * sizeof(double));
	if (!slice_depth)
		ERROR("Memory allocation failed");

	// the main circle
	while (n > 0)
	{
		int i;
		int size;
		int temp_length;			
		int noNondominatedPoints;
		int isDominate_flag;	// this flag is used to denote the domination relation
		int isInSet_flag;		// this flag is used to denote whether a point is in a set		

		double tempVolume, area;
		double lowest_upperbound;	
		double **temp;			
		
		tempVolume = 0;
		temp_length = 1;
		size = n;

		// array temp is used to store the points which are used to calculate the area of this slice
		allocate_memory(&temp, size);

		if (noObjectives > 3)
			tempVolume = CalculateHypervolume(front, n, noObjectives - 1);
		
		// sort the remaining points in descending order at the 'noObjectives'th Objective
		Sort(front, n, noObjectives);

		// copy the 1st point in front to the array temp
		copy(temp, front, 0, 0);
		
		// calculate the current slice
		lowest_upperbound = getBound(front, noPoints, noObjectives, 0);
		slice_depth[slice_number] = fabs(temp[0][noObjectives - 1] - lowest_upperbound);
		
		if (noObjectives == 3)
		{	// copy the useful points to the temp array
			for (i = 1; i < n; i++)
			{	// pick the points which have the same value at the 3rd dimension
				if (front[i][noObjectives - 1] == temp[0][noObjectives - 1])
				{
					copy(temp, front, temp_length, i);
					temp_length++;
				}
			}

			// check whether the point1 is dominated or not at the first 'noObjectives - 1' dimensions
			isDominate_flag = Check_Dominate (front, n, noObjectives - 1);
			if (isDominate_flag == 1)
			{
				area = CalculateArea (temp, temp_length, noObjectives);
				tempVolume = area;
				noNondom++;
			}
			else
			{	// pick the nondominated points at the first 'noObjectives - 1' dimensions
				noNondominatedPoints = FilterNondominatedSet(front, n, noObjectives - 1);
				for (i = 0; i < noNondominatedPoints; i++)
				{
					// check whether the nondominated points are already in the temp array or not
					isInSet_flag = Is_In_Set(temp, temp_length, front[i]);
					if (isInSet_flag == 1)
						continue;
					else
					{
						copy(temp, front, temp_length, i);
						temp_length++;
					}
				}
				area = CalculateArea(temp, temp_length, noObjectives);
				tempVolume = area;
			}
		}

		tempVolume = slice_depth[slice_number] * tempVolume;
		slice_number++;

		// sum the slice volume
		volume += tempVolume;
		
		// cut the useless points
		n = ReduceFront(front, n, noObjectives, slice_depth, slice_number);
		
		Deallocate_memrory(temp, size);
	}
	
	// deallocate the memory for the next recurse
	free(slice_depth);
	return volume;
}
