#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

// swap the point i and point j
void Swap(double *front[], int i, int j)
{
	double  *temp;

	temp = front[i];
	front[i] = front[j];
	front[j] = temp;
} /* Swap */

// copy the j-th point in front to the i-th point in temp
void copy (double *temp[], double *front[], int i, int j)
{
	int k;

	for (k = 0; k < dimension; k++)
		temp[i][k] = front[j][k];
} /* copy */

/* Check the integer 'x' is already in the array, '1' represents don't exist, '0' represents exist */
int IsRepeaded (int x, int array[], int size)
{
	int i;

	for (i = 0; i < size; i++)
	{
		if (x == array[i])
			break;
		else
			continue;
	}
	if (i == size)
		return 1;
	else
		return 0;
}

void Extract (double **front[], FILE *fpt, int noPoints, int noObjectives)
{
	char ch;
	int i, j;
	int random;
	int total;
	int flag;
	int now_position;
	int *random_position;
	
	double objective_value;
	double **baseFront;

	random = 1;
	total = 0;

//	srand((unsigned)time(NULL));
	randomize ();

	// check file and count points
	while (!feof (fpt))
	{
		for (i = 0; i < noObjectives && fscanf (fpt, "%e%c", &objective_value, &ch) != EOF; i++);
		if (i > 0 && i < noObjectives)
			ERROR ("data in file incomplete");
		total++;
	}

	// allocate memory
	random_position = (int *) malloc (noPoints * sizeof(int));
	if (random_position == NULL)
		ERROR ("Memory allocation failed!");
	baseFront = (double **) malloc (total * sizeof(double *));
	if (baseFront == NULL)
		ERROR ("Memory allocation failed!");
	for (i = 0; i < total; i++)
	{
		baseFront[i] = (double *) malloc (noObjectives * sizeof(double));
		if (baseFront[i] == NULL)
			ERROR ("Memory allocation failed!");
	}
	*front = malloc (noPoints * sizeof(double *));
	if (*front == NULL)
		ERROR ("Memory allocation failed!");
	for (i = 0; i < noPoints; i++)
	{
		(*front)[i] = malloc (noObjectives * sizeof(double));
		if ((*front)[i] == NULL)
			ERROR ("Memory allocation failed!");
	}

	rewind (fpt);		// Repositions the file pointer to the beginning of a file
	
	// extract
	for (i = 0; !feof (fpt); i++)
	{
		for (j = 0; j < noObjectives; j++)
		{
			fscanf(fpt, "%lf%c", &objective_value, &ch);
			baseFront[i][j] = objective_value;
		}
		if (j > 0 && j < noObjectives)
			ERROR("Data in file incomplete!");
		fscanf (fpt, "%c", &ch);
	}

	random_position[0] = 0;
	
	for (i = 0; i < noPoints; i++)
	{
		do 
		{
 			now_position = rnd (0, total - 2);
			flag = IsRepeaded (now_position, random_position, random);
		} while(flag == 0);
		random++;

		for (j = 0; j < noObjectives; j++)
			(*front)[i][j] = baseFront[i][j];
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
// Extract the points without the substitude objective from array 'front' to array 'temp'
void Extracted (double *front[], double **temp[], int substitude, int noObjetives, int noPoints)
{
	int i, j;
	int objective;

	*temp = malloc(noPoints * sizeof(double *));
	if (*temp == NULL)
		ERROR("Memory allocatition failed!");

	objective = noObjetives - 1;

	for (i = 0; i < noPoints; i++)
	{
		(*temp)[i] = malloc(objective * sizeof(double));
		if ((*temp)[i] == NULL)
			ERROR("Memory allocatition failed!");
	}

	for (i = 0; i < noPoints; i++)
	{
		for (j = 0; j < noObjetives; j++)
		{
			if (j == substitude)
				continue;
			else
				(*temp)[i][j] = front[i][j];
		}
	}
}

// Statistic the number of dominated pionts
int Statistics (double *front[], int noObjectives, int noPoints)
{
	int i, j;
	int flag;
	int Dominated;

	Dominated = 0;

	for (i = 0; i < noPoints; i++)
	{
		for (j = 0; j < noPoints; j++)
		{
			if (j == i)
				continue;
			else
			{
				flag = Dominates (front[i], front[j], noObjectives);
				if (flag == 1)
					Dominated++;
				else
					continue;
			}
		}
	}

	return Dominated;
}

void MDP (double *front[], int *noDominated, int noPoints, int noObjectives)
{
	int i;
	int objective;
	double **temp;

	objective = noObjectives - 1;
	
	for (i = 0; i < noObjectives; i++)
	{
		Extracted (front, &temp, i, noObjectives, noPoints);
		noDominated[i] = Statistics (temp, noObjectives, noPoints);
	}
}

void Reduce (double *front[], int *noDominated, int chosen, int noPoints, int objectives)
{
	int i;
	int temp;
	double temp_point;

	for (i = 0; i < noPoints; i++)
	{
		temp_point = front[i][objectives - 1];
		front[i][objectives - 1] = front[i][chosen];
		front[i][chosen] = temp_point;
	}
	
	temp = noDominated[chosen];
	noDominated[chosen] = noDominated[objectives - 1];
	noDominated[objectives - 1] = temp;
}

int Max (int *noDominated, int objective)
{
	int i;
	int max, max_num;

	max = noDominated[0];
	max_num = 0;
	for (i = 0; i < objective; i++)
	{
		if (noDominated[i] > max)
		{
			max = noDominated[i];
			max_num = i;
		}
	}

	return max_num;
}

void Heuristics (double *front[], int noPoints, int noObjectives)
{
	int i;
	int objective;
	int chosen;
	int *noDominated;


	objective = noObjectives;

	noDominated = (int *) malloc (noObjectives * sizeof(int));
	if (noDominated == NULL)
		ERROR("Memory allocation failed!");

	for (i = 0; i < noObjectives; i++)
	noDominated[i] = 0;

	for (i = 0; i < noObjectives; i++)
	{
		MDP (front, noDominated, noPoints, objective);
		chosen = Max (noDominated, objective);
		Reduce (front, noDominated, chosen, noPoints, objective);
		--objective;
	}
	
//	free(noDominated);
}


void Heuristics_change (double *front[], int noPoints, int noObjectives)
{
	int i, j, k;
	int objective;
	int chosen;
	int *noDominated;
	double **temp;

	objective = noObjectives;

	temp = (double **) malloc (noPoints * sizeof(double *));
	if (temp == NULL)
		ERROR ("Memory allocatition failed!");
	for (i = 0; i < noPoints; i++)
	{
		temp[i] = (double *)malloc(noObjectives * sizeof(double));
		if (temp[i] == NULL)
			ERROR ("Memory allocatition failed!");
	}

	noDominated = (int *)malloc(noObjectives * sizeof(int));
	if (noDominated == NULL)
		ERROR ("Memory allocation failed!");

	for (i = 0; i < noObjectives; i++)
		noDominated[i] = 0;

	for (i = 0; i < noObjectives; i++)
	{
		MDP (front, noDominated, noPoints, objective);
		chosen = Max (noDominated, objective);
		Reduce (front, noDominated, chosen, noPoints, objective);
		objective--;
	}

	for (i = 0; i < noPoints; i++)
	{
		for (j = 0, k = noObjectives - 1; j < noObjectives && k >= 0; j++, k--)
			temp[i][j] = front[i][k];
	}

	for (i = 0; i < noPoints; i++)
	{
		for (j = 0; j < noObjectives; j++)
			front[i][j] = temp[i][j];
	}

	free (temp);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////