#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

// allocate memory
void allocate_memory(double **front[], int noPoints)
{
	int i;

	*front = malloc(noPoints * sizeof(double *));
	if (front == NULL)
		ERROR("memory allocation failed");
	for (i = 0; i < noPoints; i++)
	{
		(*front)[i] = malloc(dimension * sizeof(double));
		if ((*front)[i] == NULL)
			ERROR("memory allocation failed");
	}
}

// deallocate memory
void Deallocate_memrory(double *front[], int noPoints)
{
	int i;

	if (front != NULL)
	{
		for (i = 0; i < noPoints; i++)
		{
			if (front[i] != NULL)
				free(front[i]);
		}
		free(front);
	}
}