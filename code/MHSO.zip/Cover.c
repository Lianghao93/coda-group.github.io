#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

/* If this point is already in the array temp, then returns 1, else returns 0 */
int Is_In_Set (double *temp[], int temp_length, double *point)
{
	int i, j;
	int flag1, flag2;

	flag1 = 0;
	flag2 = 0;

	for (i = 0; i < temp_length; i++)
	{
		for (j = 0; j < dimension; j++)
		{
			if (temp[i][j] == point[j])
				flag1 = 1;
			else
			{
				flag2 = 1;
				break;
			}
		}
		if (flag1 == 1 && flag2 == 0)
			break;
		flag1 = 0;
		flag2 = 0;
	}

	if (flag1 == 1 && flag2 == 0)
		return 1;
	else
		return 0;
}