#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

/* filter the front at the first noObjectives - 1 dimension */
int FilterNondominatedSet (double *front[], int noPoints, int noObjectives)
{
	int  i, j;
	int  n;

	n = noPoints;
	i = 0;

	while (i < n) 
	{
		j = i + 1;

		while (j < n) 
		{
			if (Dominates (front[i], front[j], noObjectives)) 
			{
			/* remove point 'j' */
				n--;
				Swap (front, j, n);
			}
			else if (Dominates (front[j], front[i], noObjectives)) 
			{
			/* remove point 'i'; ensure that the point copied to index 'i'
			   is considered in the next outer loop (thus, decrement i) */
				n--;
				Swap (front, i, n);
				i--;
				break;
			}
			else
				j++;
		}
		i++;
	}
	return n;
}