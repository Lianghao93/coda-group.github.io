#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

// Get the j-th point's lowest upper bound at the i-th dimension 
double getBound (double *front[], int noPoints, int i, int j)
{
	int k, bound_length;
	double upperbound, value, threshold;
	double *tempbound;
	
	bound_length = 0;		// the number of bounds
	
	// this array is used to store the bound value of the j-th point
	tempbound = (double *) malloc ((noPoints + 1) * sizeof(double));
	
	// threshold is the value of j-th point at i-th dimension
	threshold = front[j][i - 1];
	
	for (k = 0; k < noPoints; k++)
	{
		value = front[k][i - 1];
		if (value > threshold)
		{
			tempbound[bound_length] = value;
			bound_length++;
		}
	}
	tempbound[bound_length] = reference[i - 1];

	upperbound = tempbound[0];
	for (k = 0; k < bound_length; k++)
	{
		if (tempbound[k] < upperbound)
			upperbound = tempbound[k];	
	}
	
	free (tempbound);
	return upperbound;
}

