#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"


// read data from a specific file
int  ReadFile(double **front[], FILE *fpt, int noObjectives)
{
	int noPoints;
	int i, j;
	double objective_value;
	char ch;

	noPoints = 0;
	
	// check file and count points
	while (!feof(fpt))
	{
		for (i = 0; i < noObjectives && fscanf(fpt, "%e%c", &objective_value, &ch) != EOF; i++);
		if (i > 0 && i < noObjectives)
			ERROR("data in file incomplete");
		noPoints++;
	}
	
	// allocate memory
	*front = malloc(noPoints * sizeof(double *));
	if (*front == NULL)
		ERROR("memory allcation failed");
	for (i = 0; i < noPoints; i++)
		(*front)[i] = malloc(noObjectives * sizeof(double));
	if ((*front)[i] == NULL)
		ERROR("memory allcation failed");

	// read file data
	rewind(fpt);		// Repositions the file pointer to the beginning of a file
	noPoints = 0;
	
	for (i = 0; !feof(fpt); i++)
	{
		for (j = 0; j < noObjectives; j++)
		{
			fscanf(fpt, "%lf%c", &objective_value, &ch);
			(*front)[i][j] = objective_value;
		}
		if (j > 0 && j < noObjectives)
			ERROR("data in file incomplete");
		fscanf(fpt, "%c", &ch);
		noPoints++;
	}

	if (noPoints < 1)
		ERROR("This File contains no data");

	return noPoints;
}