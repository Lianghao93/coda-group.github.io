#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

// calculate the 2D area of the projected points
double CalculateArea(double *front[], int noPoints, int noObjectives)
{
	int i;
	double diff1, diff2;
	double s_value;
	
	s_value = 0;
	diff1 = 0;
	diff2 = 0;
	
	// sort the points in descending order at 1st dimension
	Sort(front, noPoints, 1);

	for (i = 0; i < noPoints; i++)
	{
		if (i == 0)
			diff1 = front[i][noObjectives - 3] - reference[noObjectives - 3];
		else
			diff1 = front[i][noObjectives - 3] - front[i - 1][noObjectives - 3];
		diff2 = front[i][noObjectives - 2] - reference[noObjectives - 2]	;

		s_value += (double)(fabs(diff1) * fabs(diff2));
	}

	return s_value;
}

double CalculateArea_2D(double *front[], int noPoints, int noObjectives)
{
	int i;
	double diff1, diff2;
	double s_value;
	
	s_value = 0;
	diff1 = 0;
	diff2 = 0;
	
	// sort the points in descending order at 1st dimension
	Sort (front, noPoints, 1);

	for (i = 0; i < noPoints; i++)
	{
		if (i == 0)
			diff1 = front[i][noObjectives - 2] - reference[noObjectives - 2];
		else
			diff1 = front[i][noObjectives - 2] - front[i - 1][noObjectives - 2];
		diff2 = front[i][noObjectives - 1] - reference[noObjectives - 1]	;

		s_value += (double)(fabs(diff1) * fabs(diff2));
	}

	return s_value;
}
