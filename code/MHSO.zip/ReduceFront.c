#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "rand.h"

/* reduce the useless points in the current front */
int ReduceFront(double *front[], int noPoints, int noObjectives, double *slice_depth, int slice_number)
{
	int n;
	int i;
	double threshold;

	threshold = 0;
	n = noPoints;
	
	for (i = 0; i < slice_number; i++)
		threshold += slice_depth[i];

	for (i = 0; i < n; i++)
	{
		if (fabs (reference[noObjectives - 1] - front[i][noObjectives - 1]) <= threshold)
		{
			n--;
			Swap (front, i, n);
			i--;
		}
	}
	
	return n;
}