%% This function is used to sample weight vectors on the simplex, we use a multi-layer method to serve this purpose.

function W = extract_weight(objDim)

    no_gaps1 = 5;
    no_gaps2 = 5;
    no_gaps3 = 5;

    shrink_factor = [0.2, 0.4, 0.6, 0.8];

    weight_size1 = nchoosek(objDim + no_gaps1 - 1, no_gaps1);
    weight_size2 = nchoosek(objDim + no_gaps2 - 1, no_gaps2);
    weight_size3 = nchoosek(objDim + no_gaps3 - 1, no_gaps3);
    
    % generate the first layer
    first_layer = initweight(objDim, weight_size1);
    
    % generate the temp layer
    temp_layer = initweight(objDim, weight_size2);

    % get the second layer by shrinking the temp layer (coordinate transformation)
    second_layer = (1 - shrink_factor(1)) / objDim * ones(objDim, weight_size2) + shrink_factor(1) * temp_layer;
    
    % generate the temp layer
    temp_layer = initweight(objDim, weight_size3);

    % get the third layer by shrinking the temp layer (coordinate transformation)
    third_layer = (1 - shrink_factor(2)) / objDim * ones(objDim, weight_size3) + shrink_factor(2) * temp_layer;
    
    % get the fourth layer by shrinking the temp layer (coordinate transformation)
    fourth_layer = (1 - shrink_factor(3)) / objDim * ones(objDim, weight_size3) + shrink_factor(3) * temp_layer;
    
    % get the fifth layer by shrinking the temp layer (coordinate transformation)
    fifth_layer = (1 - shrink_factor(4)) / objDim * ones(objDim, weight_size3) + shrink_factor(4) * temp_layer;
    
    W = [first_layer'; second_layer'; third_layer'; fourth_layer'; fifth_layer'];
end