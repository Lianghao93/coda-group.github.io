%% This function is used to sample points on the PF of DTLZ instance

function P = samplingIGD(objDim, no_gaps1, no_gaps2, sample_size, id)

    % generate the reference vectors
    if objDim < 6
        W = initweight(objDim, sample_size);
        W = W';
    else
%         W = extract_weight(objDim, no_gaps1, no_gaps2);
        W = extract_weight(objDim);
    end
    
    if id == 1           % ZDT1
        step    = 1 / (sample_size - 1);
        P       = zeros(sample_size, objDim);
        f1      = 0 : step : 1;
        P(:, 1) = f1';
        P(: ,2) = ones(sample_size, 1) - sqrt(P(:, 1));
    elseif id == 2       % ZDT2
        step    = 1 / (sample_size - 1);
        P       = zeros(sample_size, objDim);
        f1      = 0 : step : 1;
        P(:, 1) = f1';
        P(: ,2) = ones(sample_size, 1) - P(:, 1).^2;
    elseif id == 3       % ZDT3
        step    = 1.0 / (sample_size - 1);
        f1      = 0 : step : 1;
        P(:, 1) = f1;
        P(:, 2) = 1 - sqrt(f1) - f1 .* sin(10 * pi * f1);
        P       = find_nondominated(P, 2);
    elseif id == 4       % DTLZ1
        denominator = sum(W, 2);
        deMatrix = denominator(:, ones(objDim, 1));
        
        P = W ./ (2 * deMatrix);
    elseif id == 5   % DTLZ2-DTLZ4
        tempW = W .* W;
        denominator = sum(tempW, 2);
        deMatrix = denominator(:, ones(objDim, 1));

        P = W ./ sqrt(deMatrix);
    elseif id == 6   % DTLZ5-DTLZ6
        theta = [0 : 1 / (sample_size - 1) : 1];
        f1    = cos(theta * pi / 2) * cos(pi / 4);
        f2    = cos(theta * pi / 2) * sin(pi / 4);
        f3    = sin(theta * pi / 2);
        
        P = zeros(sample_size, objDim);
        P(:, 1) = f1';
        P(:, 2) = f2';
        P(:, 3) = f3';
    elseif id == 7   % DTLZ7
        step = sqrt(sample_size);
        f1 = 0 : 1 / (step - 1) : 1;
        f2 = f1;

        P = zeros(step * step, objDim);
        for i = 1 : step
            for j = 1 : step
                idx = (i - 1) * step + j;
                P(idx, 1) = f1(i);
                P(idx, 2) = f2(j);
            end
        end
        t1 = P(:, 1) .* (ones(sample_size, 1) + sin(3 * pi * P(:, 1)));
        t2 = P(:, 2) .* (ones(sample_size, 1) + sin(3 * pi * P(:, 2)));
        P(:, 3) = 3 - t1 - t2;
        P = find_nondominated(P, objDim);
    else
        error('Bad id!');
    end
    
end

function x = dominated_relationship(a, b, m)
% ֧���ϵ�ж�
% ��ڲ�����a -����1��b -����2��m -Ŀ��ά����
% ���ڲ�����x -1,a֧��b; 2,b֧��a; 3,ab���; 4,ab����֧��;
    t = 0;
    q = 0;
    p = 0;

    e = 0.00001;
    for i = 1 : m
        if a(i) <= b(i)
            t = t + 1;
        end
        if  a(i) >= b(i)
            q = q + 1;
        end
        if  a(i) == b(i)
            p = p + 1;
        end
    end
    % for i=1:m
    %     if fix(a(1,c+i)/e)<=fix(b(1,c+i)/e)
    %         t=t+1;
    %     end
    %     if  fix(a(1,c+i)/e)>= fix(b(1,c+i)/e)
    %         q=q+1;
    %     end
    %     if  fix(a(1,c+i)/e)== fix(b(1,c+i)/e)
    %         p=p+1;
    %     end
    % end
    if t == m & p ~= m
        x = 1;
    elseif q == m & p ~= m
        x = 2;
    elseif p == m
        x = 3;
    else
        x = 4;
    end
end

function NPOP = find_nondominated(POP, m)
%Ѱ�ҷ�֧���
%��ڲ�����POP-��Ⱥ,c-��������,m-Ŀ�����
%���ڲ�����NPOP-��֧��⼯

i = 1;
while i <= size(POP, 1)
    flag = 0;
    j = i + 1;
    while j <= size(POP, 1)
        x = dominated_relationship(POP(i, :), POP(j, :), m);
        if x == 2
            flag = 1;
            break;
        elseif x == 3
            POP(j, :) = [];
        elseif x == 1
            POP(j, :) = [];
        else
            j = j + 1;
        end
    end
    if flag == 1
        POP(i, :) = [];
    else
        i = i + 1;
    end
end
NPOP = POP;
end