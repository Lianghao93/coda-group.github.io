% ------------------------------------------------------------------------%
% This script is used to sample some Pareto-optimal points on the PF of
% some established test problems.
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (www.cs.ctiyu.edu.hk/~51888309)
% Last modified: 2015.10.21
% ------------------------------------------------------------------------%

close all
clear
clc

format long

objDim      = 3;
no_gaps1    = 1;
no_gaps2    = 1;
sample_size = 91;
problem_id  = 5; % id = 1: ZDT1 | id = 2: ZDT2 | id = 3: ZDT3 | id = 4: DTLZ1
                 % id = 5: DTLZ2-DTLZ4 | id = 6: DTLZ5-DTLZ6 id = 7: DTLZ7

W = samplingIGD(objDim, no_gaps1, no_gaps2, sample_size, problem_id);

if objDim == 2
    plot(W(:, 1), W(:, 2), 'o');
elseif objDim == 3
    plot3(W(:, 1), W(:, 2), W(:, 3), 'o');
else
    parallelcoords(P);
end