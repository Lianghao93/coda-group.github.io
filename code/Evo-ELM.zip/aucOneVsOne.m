function output = aucOneVsOne(targets, outputs, label)

    row    = size(targets, 1);
    output = 0;
    
    for i = 1 : row
        for j = i + 1 : row
            targets1 = [targets(i, label == i)'; targets(i, label == j)']';
            outputs1 = [outputs(i, label == i)'; outputs(i, label == j)']';
            auc1 = aucStatistic(targets1, outputs1); 
           
            
            targets2 = [targets(j, label == i)'; targets(j, label == j)']';
            outputs2 = [outputs(j, label == i)'; outputs(j, label == j)']';

            auc2 = aucStatistic(targets2, outputs2);

            output = output + (auc1 + auc2) / 2;
        end
    end
    
    output = output * 2 / (row * (row - 1));
   
%     plotroc(targets,outputs);
%     legend('FontSize',18,'Location','SouthEast');

end