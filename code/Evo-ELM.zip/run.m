totalrun = 1;
NumberOfHiddenNodes = 50;
Elm_Type = 1;
ActivationFunction = 'sig';
AUC_Type = 1;

outcome = zeros(totalrun, 7);

load('classification.mat');

for i = 1 : totalrun
    fprintf('The %dth Running \n', i);
    [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy, auc_value_train, auc_value_test, TotalTime] = MyDE2(Wine_train, Wine_test, Elm_Type, NumberOfHiddenNodes, ActivationFunction, AUC_Type);
    outcome(i, :) = [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy, auc_value_train, auc_value_test, TotalTime];
end

Wine = outcome
save Wine Wine