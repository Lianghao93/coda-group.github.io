function [trdata, tedata] = randomselect2(data, r) 
   
    num = max(data(:, 1));
    dim = size(data, 2);
    
    data_class = cell(1, num);
    for i = 1 : num
       data_class{1, i} = data(data(:, 1)==i, :); 
    end
    
    data_class_tr = cell(1, num);
    data_class_te = cell(1, num);

    for i = 1 : num
        [data_class_tr{1, i}, data_class_te{1, i}] = randomselect(data_class{1, i}, r); 
    end

    trdata = zeros(0, dim);
    tedata = zeros(0, dim);
    for i = 1 : num
        trdata = [trdata; data_class_tr{1, i}];
        tedata = [tedata; data_class_te{1, i}];
    end
   
end