function [Fm, CRm] = updateMean(Success_F, Success_CR, eta, NumberOfStrategies, Fm, CRm)

scale = 1.5;
w_F  = 0.8 + 0.2 * rand;
w_CR = 0.9 + 0.1 * rand;

% c = 0.01;
% for i = 1 : NumberOfStrategies
%     Fm(1, i)  = (1 - c) * Fm(1, i) + c * sum(Success_F(i, :) .^ 2) / sum(Success_F(i, :));
%     CRm(1, i) = (1 - c) * CRm(1, i) + c * mean(Success_CR(i, :));
% end

for i = 1 : NumberOfStrategies
    if eta(1, i) ~= 0
        Success_F(i, :)  = (Success_F(i, :) .^ scale) / (sum(Success_F(i, :) > 0));
        Success_CR(i, :) = (Success_CR(i, :) .^ scale) / (sum(Success_CR(i, :) > 0));
    else
        Success_F(i, :) = 0;
    end
end

for i = 1 : NumberOfStrategies
    if eta(1, i) ~= 0
        Fm(1, i)  = (1 - w_F) * Fm(1, i) + w_F * sum(Success_F(i, :));
        CRm(1, i) = (1 - w_CR) * CRm(1, i) + w_CR * sum(Success_CR(i, :));
    else
        Fm(1, i)  = 0.5;
        CRm(1, i) = 0.5;
    end
end

end

