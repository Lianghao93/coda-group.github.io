function [P, T, TV, Labels_train, Labels_test] = dataProcess(TrainingData_File, TestingData_File, Elm_Type)

    %*********************** Load training dataset ***************************%
    T = TrainingData_File(:, 1)';
    P = TrainingData_File(:, 2 : end)';

    %************************* Load testing dataset **************************%
    TV.T = TestingData_File(:, 1)';
    TV.P = TestingData_File(:, 2 : end)';

    Labels_train = TrainingData_File(:, 1)';
    Labels_test  = TestingData_File(:, 1)';
    
    NumberofTrainingData = size(P, 2);
    NumberofTestingData  = size(TV.P, 2);

    if Elm_Type ~= 0
        % Preprocessing the data of classification
        sorted_target = sort(cat(2, T, TV.T), 2);
        % Find and save in 'label' class label from training and testing data sets
        label         = zeros(1, 1);
        label(1, 1)   = sorted_target(1, 1);
        j = 1;
        for i = 2 : (NumberofTrainingData + NumberofTestingData)
            if sorted_target(1, i) ~= label(1, j)
                j           = j + 1;
                label(1, j) = sorted_target(1, i);
            end
        end
        number_class          = j;
        NumberofOutputNeurons = number_class;

        % Processing the targets of training
        temp_T = zeros(NumberofOutputNeurons, NumberofTrainingData);
        for i = 1 : NumberofTrainingData
            for j = 1 : number_class
                if label(1, j) == T(1, i)
                    break; 
                end
            end
            temp_T(j, i) = 1;
        end
        T = temp_T * 2 - 1;

        % Processing the targets of testing
        temp_TV_T = zeros(NumberofOutputNeurons, NumberofTestingData);
        for i = 1 : NumberofTestingData
            for j = 1:number_class
                if label(1,j) == TV.T(1, i)
                    break; 
                end
            end
            temp_TV_T(j, i) = 1;
        end
        TV.T = temp_TV_T * 2 - 1;
    end
    clear temp_T;
    clear temp_T;    
end

