function [TrainingTime, TestingTime, ACC, AUC, OutputWeight] = elm_train_AUC(P, T, TV, Labels_train, Elm_Type, ActivationFunction, InputWeight, BiasofHiddenNeurons, AUC_Type)

%*************************** Macro definition ****************************%
REGRESSION = 0;
CLASSIFIER = 1;

NumberofTrainingData = size(P, 2);
NumberofTestingData  = size(TV. P, 2);

if Elm_Type ~= REGRESSION
    % Preprocessing the data of classification
    sorted_target = sort(cat(2, T, TV.T), 2);
    % Find and save in 'label' class label from training and testing data sets
    label         = zeros(1, 1);
    label(1, 1)   = sorted_target(1, 1);
    j = 1;
    for i = 2 : (NumberofTrainingData + NumberofTestingData)
        if sorted_target(1, i) ~= label(1, j)
            j           = j + 1;
            label(1, j) = sorted_target(1, i);
        end
    end
    number_class          = j;
    NumberofOutputNeurons = number_class;
       
    % Processing the targets of training
    temp_T = zeros(NumberofOutputNeurons, NumberofTrainingData);
    for i = 1 : NumberofTrainingData
        for j = 1 : number_class
            if label(1, j) == T(1, i)
                break; 
            end
        end
        temp_T(j, i) = 1;
    end
    T = temp_T * 2 - 1;

    % Processing the targets of testing
    temp_TV_T = zeros(NumberofOutputNeurons, NumberofTestingData);
    for i = 1 : NumberofTestingData
        for j = 1:number_class
            if label(1,j) == TV.T(1, i)
                break; 
            end
        end
        temp_TV_T(j, i) = 1;
    end
    TV.T = temp_TV_T * 2 - 1;
end

%*********************** Calculate weights & biases **********************%
start_time_train = cputime;

tempH = InputWeight * P;
% Release input of training data 
clear P;
ind        = ones(1, NumberofTrainingData);
% Extend the bias matrix BiasofHiddenNeurons to match the demention of H
BiasMatrix = BiasofHiddenNeurons(:, ind);
tempH      = tempH + BiasMatrix;

%************** Calculate hidden neuron output matrix H ******************%
switch lower(ActivationFunction)
    case {'sig','sigmoid'}
        % Sigmoid
        H = 1 ./ (1 + exp(-tempH));
    case {'sin','sine'}
        % Sine
        H = sin(tempH);    
    case {'hardlim'}
        % Hard Limit
        H = double(hardlim(tempH));
    case {'tribas'}
        % Triangular basis function
        H = tribas(tempH);
    case {'radbas'}
        % Radial basis function
        H = radbas(tempH);
        % More activation functions can be added here                
end
% Release the temparary array for calculation of hidden neuron output matrix H
clear tempH;

%************ Calculate output weights OutputWeight (beta_i) *************%
OutputWeight = pinv(H') * T';                         % slower implementation

end_time_train = cputime;
TrainingTime   = end_time_train - start_time_train; %   Calculate CPU time (seconds) spent for training ELM

Y = (H' * OutputWeight)';

clear H;

%***************** Calculate the output of testing input *****************%
start_time_test = cputime;
tempH_test      = InputWeight * TV.P;
% Release input of testing data
clear TV.P;

ind        = ones(1, NumberofTestingData);
% Extend the bias matrix BiasofHiddenNeurons to match the demention of H
BiasMatrix = BiasofHiddenNeurons(:, ind);
tempH_test = tempH_test + BiasMatrix;
switch lower(ActivationFunction)
    case {'sig','sigmoid'}
        % Sigmoid 
        H_test = 1 ./ (1 + exp(-tempH_test));
    case {'sin','sine'}
        % Sine
        H_test = sin(tempH_test);        
    case {'hardlim'}
        % Hard Limit
        H_test = hardlim(tempH_test);        
    case {'tribas'}
        % Triangular basis function
        H_test = tribas(tempH_test);        
    case {'radbas'}
        % Radial basis function
        H_test = radbas(tempH_test);        
        % More activation functions can be added here        
end
% TY: the actual output of the testing data
TY            = (H_test' * OutputWeight)';
end_time_test = cputime;
% Calculate CPU time (seconds) spent by ELM predicting the whole testing data
TestingTime   = end_time_test - start_time_test;

%*********************** Calculate training AUC **************************%
%Targets_train = T == 1;
%Outputs_train = (mapminmax(Y) + 1) / 2;

Targets_train = TV.T == 1;
Outputs_train = (mapminmax(TY) + 1) / 2;
if size(unique(Labels_train), 2) == 2
    Labels_train = Labels_train + 1;
end
switch AUC_Type
    case 1
        AUC = aucOneVsAll(Targets_train, Outputs_train);
    case 0
        AUC = aucOneVsOne(Targets_train, Outputs_train, Labels_train);
end

if Elm_Type == CLASSIFIER
%********** Calculate training & testing classification accuracy *********%
    MissClassificationRate  = 0;
    for i = 1 : size(TV.T, 2)
        [x, label_index_expected] = max(TV.T(:, i));
        [x, label_index_actual]   = max(TY(:, i));
        if label_index_actual ~= label_index_expected
            MissClassificationRate = MissClassificationRate + 1;
        end
    end
    ACC = 1 - MissClassificationRate / size(TV.T, 2);
else
    ACC = sqrt(mse(TV.T - TY));
end