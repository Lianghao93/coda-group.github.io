function [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy, auc_value_train, auc_value_test, TotalTime] = MyDE2(TrainingData_File, TestingData_File, Elm_Type, NumberOfHiddenNodes, ActivationFunction, AUC_Type)

    %*********************** Load training dataset ***********************%
    T = TrainingData_File(:, 1)';
    P = TrainingData_File(:, 2 : end)';

    %*********************** Load testing dataset ************************%
    TV.T = TestingData_File(:, 1)';
    TV.P = TestingData_File(:, 2 : end)';
    
    Labels_train = TrainingData_File(:, 1)';
    Labels_test  = TestingData_File(:, 1)';
    
    %********************** Load validation dataset **********************%
%     [TrainingData_File, TestingData_File] = randomselect2(TrainingData_File, 0.8);
%     TV.T = temp1(:, 1)';
%     TV.P = temp1(:, 2 : end)';
%     VV.T = temp2(:, 1)';
%     VV.P = temp2(:, 2 : end)';
    
    StartTime = cputime;
    
    %rand('seed', sum(100 * clock));
       
    tolerance = 0.02;
    
    % Generation count
    generation = 1;

    % Maximum number of generations
    MaxGen = 100;

    % Define the population size
    popsize = 100;
    
    % Define the number of strategies in the strategies pool
    NumberOfStrategies = 4;
    
    % Define a strategy flag array to record the used strategy
    strategy_flag = zeros(1, popsize);
    
    % Define the credit values array
    eta = zeros(1, NumberOfStrategies);
    
    % Define the rewards array
    reward = zeros(1, NumberOfStrategies);
    
    % Define the quality array
    quality = zeros(1, NumberOfStrategies);
    
    % Define the probability array
    probability       = zeros(1, NumberOfStrategies);
    probability(1, :) = 1 / NumberOfStrategies;
    
    % Define the adaptation rate
    alpha = 0.3;
    %beta  = 0.8;
    
    % Define the minimum selection probability
    p_min = 0.05;
    %p_max = 1 - (NumberOfStrategies - 1) * p_min;
    
    % Control parameters: F & CR
    F   = zeros(NumberOfStrategies, popsize);
    CR  = zeros(NumberOfStrategies, popsize);
    
    % Mean value of control parameters: F & CR
    Fm        = zeros(1, NumberOfStrategies);
    CRm       = zeros(1, NumberOfStrategies);
    Fm(1, :)  = 0.5;
    CRm(1, :) = 0.5;
    Fsigma    = 0.1;
    CRsigma   = 0.1;
    VV.T      = TV.T;
    VV.P      = TV.P;
    
    % Successful control parameter values
    Success_F  = zeros(NumberOfStrategies, popsize);
    Success_CR = zeros(NumberOfStrategies, popsize);
        
    % Define the number of input nodes
    NumberOfInputNodes  = size(TrainingData_File, 2) - 1;
    
    % Define the lower and upper bounds weight: [-1,1]
    lower_bound_weight = -1 .* ones(NumberOfHiddenNodes, NumberOfInputNodes); 
    upper_bound_weight = 1 .* ones(NumberOfHiddenNodes, NumberOfInputNodes);     
    
    % Define the lower and upper bounds bias: [0, 1]
    lower_bound_bias = -1 .* ones(NumberOfHiddenNodes, 1); 
    %lower_bound_bias = zeros(NumberOfHiddenNodes, 1); 
    upper_bound_bias = 1 .* ones(NumberOfHiddenNodes, 1);

    % Initialize the main population
    parent_struct    = cell(1, popsize);
    offspring_struct = cell(1, popsize);
    for i = 1 : popsize
        parent_struct{1, i}       = cell(1, 3);
        parent_struct{1, i}{1, 1} = lower_bound_weight + rand(NumberOfHiddenNodes, NumberOfInputNodes) .* (upper_bound_weight - lower_bound_weight);
        parent_struct{1, i}{1, 2} = lower_bound_bias + rand(NumberOfHiddenNodes, 1) .* (upper_bound_bias - lower_bound_bias);
        parent_struct{1, i}{1, 3} = 0;
    end

    theta = 0.005;
    % Evaluate the fitness function values of the initial population and find out the best solution
    % [parent_struct{1, i}{1, 3}, OutputWeight] = elm_train(P, T, TV, Elm_Type, ActivationFunction, parent_struct{1, i}{1, 1}, parent_struct{1, i}{1, 2});
    [TrainingTime, TestingTime, ACC, AUC, OutputWeight] = elm_train_AUC(P, T, VV, Labels_test, Elm_Type, ActivationFunction, parent_struct{1, 1}{1, 1}, parent_struct{1, 1}{1, 2}, AUC_Type);
    parent_struct{1, 1}{1, 3} = ACC;
    %parent_struct{1, 1}{1, 3} = ACC + AUC - theta * norm(OutputWeight, 2);
    %parent_struct{1, 1}{1, 3} = 0.7 * AUC + 0.3 * ACC;
    bestFitness  = parent_struct{1, 1}{1, 3};
    bestSolution = parent_struct{1, 1};
    bestWeight   = OutputWeight;
    for i = 2 : popsize
        % [parent_struct{1, i}{1, 3}, OutputWeight] = elm_train(P, T, TV, Elm_Type, ActivationFunction, parent_struct{1, i}{1, 1}, parent_struct{1, i}{1, 2});
        [TrainingTime, TestingTime, ACC, AUC, OutputWeight] = elm_train_AUC(P, T, VV, Labels_test, Elm_Type, ActivationFunction, parent_struct{1, i}{1, 1}, parent_struct{1, i}{1, 2}, AUC_Type);
        parent_struct{1, i}{1, 3} = ACC;
        %parent_struct{1, i}{1, 3} = ACC + AUC - theta * norm(OutputWeight, 2);
        %parent_struct{1, i}{1, 3} = 0.7 * AUC + 0.3 * ACC;
        if parent_struct{1, i}{1, 3} > bestFitness
           bestFitness  = parent_struct{1, i}{1, 3};
           bestSolution = parent_struct{1, i};
           bestWeight   = OutputWeight;
       end
    end

    counter = 0;
    while generation <= MaxGen
        fprintf('%dth generation\t Best fitness:%f \n', generation, bestFitness);
        
        % Refreshment
        eta(1, :) = 0;
        
        parent_struct_Temp = parent_struct;       
        
        for i = 1 : popsize
            % Select a strategy via Roullite Wheel Selection
            strategy_flag(1, i) = roulette_wheel_selection(probability);
            
            % Generate the corresponding control parameters: F & CR
            [F(strategy_flag(1, i), i), CR(strategy_flag(1, i), i)] = randFCR(popsize, CRm(1, strategy_flag(1, i)), CRsigma, Fm(1, strategy_flag(1, i)), Fsigma);
            
            % Generate the trail vectors
            offspring_struct{1, i} = generator(parent_struct, i, bestSolution, strategy_flag(1, i), F(strategy_flag(1, i), i), CR(strategy_flag(1, i), i), popsize, lower_bound_weight, upper_bound_weight, lower_bound_bias, upper_bound_bias);
            
            % Evaluate the fitness function values of the offspring population
            %[offspring_struct{1, i}{1, 3}, OutputWeight] = elm_train(P, T, TV, Elm_Type, ActivationFunction, offspring_struct{1, i}{1, 1}, offspring_struct{1, i}{1, 2});
            [TrainingTime, TestingTime, ACC, AUC, OutputWeight] = elm_train_AUC(P, T, VV, Labels_test, Elm_Type, ActivationFunction, offspring_struct{1, i}{1, 1}, offspring_struct{1, i}{1, 2}, AUC_Type);
            offspring_struct{1, i}{1, 3} = ACC;
            %offspring_struct{1, i}{1, 3} = ACC + AUC - theta * norm(OutputWeight, 2);
            %offspring_struct{1, i}{1, 3} = 0.7 * AUC + 0.3 * ACC;
            
            % Update the best solution
            if offspring_struct{1, i}{1, 3} - bestFitness > tolerance * bestFitness
                bestFitness  = offspring_struct{1, i}{1, 3};
                bestSolution = offspring_struct{1, i};
                bestWeight   = OutputWeight;
            elseif abs(bestFitness - offspring_struct{1, i}{1, 3}) < tolerance * bestFitness
                if norm(OutputWeight, 2) < norm(bestWeight, 2)
                    counter = counter + 1;
                    bestFitness  = offspring_struct{1, i}{1, 3};
                    bestSolution = offspring_struct{1, i};
                    bestWeight   = OutputWeight;
                end
            end
        end
        
        for i = 1 : popsize
            if parent_struct{1, i}{1, 3} < offspring_struct{1, i}{1, 3}
                parent_struct_Temp{1, i} = offspring_struct{1, i};
                
                % Credit Assignment & Update Successful control parameters
                temp = abs(offspring_struct{1, i}{1, 3} - parent_struct{1, i}{1, 3}) * offspring_struct{1, i}{1, 3} / bestFitness;
                
                switch strategy_flag(1, i)
                    case 1
                        eta(1, 1) = eta(1, 1) + temp;
                        Success_F(1, i)  = F(1, i);
                        Success_CR(1, i) = CR(1, i);
                    case 2
                        eta(1, 2) = eta(1, 2) + temp;
                        Success_F(2, i)  = F(2, i);
                        Success_CR(2, i) = CR(2, i);
                    case 3
                        eta(1, 3) = eta(1, 3) + temp;
                        Success_F(3, i)  = F(3, i);
                        Success_CR(3, i) = CR(3, i);
                    case 4
                        eta(1, 4) = eta(1, 4) + temp;
                        Success_F(4, i)  = F(4, i);
                        Success_CR(4, i) = CR(4, i);
                end                
            end
        end
        
        % Reward Updating
        for i = 1 : NumberOfStrategies
            if sum(strategy_flag == i) ~= 0
                reward(1, i) = eta(1, i) / sum(strategy_flag == i);
            else
                reward(1, i) = 0;
            end
        end
        
        % Quality Updating
        for i = 1 : NumberOfStrategies
            quality(1, i) = (1 - alpha) * quality(1, i) + alpha * reward(1, i);
        end
        
        % Probability Updating (Probability Matching)
        for i = 1 : NumberOfStrategies
            if sum(quality) ~= 0
                probability(1, i) = p_min + (1 - NumberOfStrategies * p_min) * quality(1, i) / sum(quality);
            else
                probability(1, i) = 1 / NumberOfStrategies;
            end
        end
        
        % Probability Updating (Adaptive Pursuit)
%         [max_quality, max_index] = max(quality);
%         for i = 1 : NumberOfStrategies
%             if i ~= max_index
%                 probability(1, i) = probability(1, i) + beta * (p_min - probability(1, i));
%             else
%                 probability(1, i) = probability(1, i) + beta * (p_max - probability(1, i));
%             end
%         end
        
        % Update mean values of control parameters
        if sum(quality) ~= 0
            [Fm, CRm] = updateMean(Success_F, Success_CR, eta, NumberOfStrategies, Fm, CRm);
        else
            Fm(1, :)  = 0.5;
            CRm(1, :) = 0.5;
        end

        parent_struct = parent_struct_Temp;
        
        generation = generation + 1;
    end   
    
    [TrainingTime, TestingTime, TrainingAccuracy, TestingAccuracy, auc_value_train, auc_value_test] = elm_test(P, T, TV, Labels_train, Labels_test, Elm_Type, ActivationFunction, bestSolution{1, 1}, bestSolution{1, 2}, bestWeight, AUC_Type);
    
    fprintf('counter = %d\n', counter);
    
    TrainingTime = 0;
    TotalTime = cputime - StartTime;

end

