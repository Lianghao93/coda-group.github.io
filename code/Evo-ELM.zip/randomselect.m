function [trdata, tedata] = randomselect(data, r) 
    [firstrow, col] = size(data);

    totnumb = round(firstrow * r);
    prov    = randperm(firstrow);
    trdata  = zeros(0, col);
    tedata  = zeros(0, col);
    tri     = 0;
    tei     = 0;
    for i = 1 : firstrow
      trans = prov(i);
      if i <= totnumb
          tri            = tri + 1;        
          trdata(tri, :) = data(trans, :);
      else
          tei            = tei + 1;
          tedata(tei, :) = data(trans, :);
      end
    end
end