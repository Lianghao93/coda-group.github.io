function u = generator(parent_struct, i, bestSolution, strategy_flag, F, CR, popsize, lower_bound_weight, upper_bound_weight, lower_bound_bias, upper_bound_bias)

% Data structure specification
u = cell(1, 3);


switch strategy_flag
    case 1
        %**************************"rand/1/bin"strategy**************************%
        % Choose the indices for mutation
        indexSet       = 1 : popsize;
        indexSet(i)    = [];

        % Choose the first Index
        temp           = floor(rand * (popsize - 1)) + 1;
        index(1)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the second index
        temp           = floor(rand * (popsize - 2)) + 1;
        index(2)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the third index
        temp     = floor(rand * (popsize - 3)) + 1;
        index(3) = indexSet(temp);

        % Mutation (weight)
        w1 = parent_struct{1, index(1)}{1, 1} + F .* (parent_struct{1, index(2)}{1, 1} - parent_struct{1, index(3)}{1, 1});

        % Mutation (bias)
        b1 = parent_struct{1, index(1)}{1, 2} + F .* (parent_struct{1, index(2)}{1, 2} - parent_struct{1, index(3)}{1, 2});

        % Handling out of boundary for weight
        new_lb_weight = 2 .* lower_bound_weight - w1;
        flag1         = new_lb_weight > upper_bound_weight;
        new_lb_weight = new_lb_weight .* (1 - flag1) + upper_bound_weight .* flag1;
        flag2         = w1 < lower_bound_weight;
        w1            = w1 .* (1 - flag2) + new_lb_weight .* flag2;

        new_ub_weight = 2 .* upper_bound_weight - w1;
        flag1         = new_ub_weight < lower_bound_weight;
        new_ub_weight = new_ub_weight .* (1 - flag1) + lower_bound_weight .* flag1;
        flag2         = w1 > upper_bound_weight;
        w1            = w1 .* (1 - flag2) + new_ub_weight .* flag2;

        % Handling out of boundary for bias
        new_lb_bias   = 2 .* lower_bound_bias - b1;
        flag1         = new_lb_bias > upper_bound_bias;
        new_lb_bias   = new_lb_bias .* (1 - flag1) + upper_bound_bias .* flag1;
        flag2         = b1 < lower_bound_bias;
        b1            = b1 .* (1 - flag2) + new_lb_bias .* flag2;

        new_ub_bias   = 2 .* upper_bound_bias - b1;
        flag1         = new_ub_bias < lower_bound_bias;
        new_ub_bias   = new_ub_bias .* (1 - flag1) + lower_bound_bias .* flag1;
        flag2         = b1 > upper_bound_bias;
        b1            = b1 .* (1 - flag2) + new_ub_bias .* flag2;

        % Binomial crossover (weight)
        j_rand                     = rand(size(w1));
        row_index                  = floor(rand * size(w1, 1)) + 1;
        col_index                  = floor(rand * size(w1, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        w1                         = w1 .* flag + parent_struct{1, i}{1, 1} .* (1 - flag);

        % Binomial crossover (bias)
        j_rand                     = rand(size(b1));
        row_index                  = floor(rand * size(b1, 1)) + 1;
        col_index                  = floor(rand * size(b1, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        b1                         = b1 .* flag + parent_struct{1, i}{1, 2} .* (1 - flag);
        
        % Offspring assignment
        u{1, 1} = w1;
        u{1, 2} = b1;
        u{1, 3} = 0;
    case 2
        %... "current to rand/1" strategy ...%
        index(1 : 3) = floor(rand(1, 3) * popsize) + 1;

        % Mutation (weight)
        w2 = parent_struct{1, i}{1, 1} + rand .* (parent_struct{1, index(1)}{1, 1} - parent_struct{1, i}{1, 1}) + F .* (parent_struct{1, index(2)}{1, 1} - parent_struct{1, index(3)}{1, 1});

        % Mutation (bias)
        b2 = parent_struct{1, i}{1, 2} + rand .* (parent_struct{1, index(1)}{1, 2} - parent_struct{1, i}{1,2}) + F .* (parent_struct{1, index(2)}{1, 2} - parent_struct{1, index(3)}{1, 2});

        % Handling out of boundary for weight
        new_lb_weight = 2 .* lower_bound_weight - w2;
        flag1         = new_lb_weight > upper_bound_weight;
        new_lb_weight = new_lb_weight .* (1 - flag1) + upper_bound_weight .* flag1;
        flag2         = w2 < lower_bound_weight;
        w2            = w2 .* (1 - flag2) + new_lb_weight .* flag2;

        new_ub_weight = 2 .* upper_bound_weight - w2;
        flag1         = new_ub_weight < lower_bound_weight;
        new_ub_weight = new_ub_weight .* (1 - flag1) + lower_bound_weight .* flag1;
        flag2         = w2 > upper_bound_weight;
        w2            = w2 .* (1 - flag2) + new_ub_weight .* flag2;

        % Handling out of boundary for bias
        new_lb_bias   = 2 .* lower_bound_bias - b2;
        flag1         = new_lb_bias > upper_bound_bias;
        new_lb_bias   = new_lb_bias .* (1 - flag1) + upper_bound_bias .* flag1;
        flag2         = b2 < lower_bound_bias;
        b2            = b2 .* (1 - flag2) + new_lb_bias .* flag2;

        new_ub_bias   = 2 .* upper_bound_bias - b2;
        flag1         = new_ub_bias < lower_bound_bias;
        new_ub_bias   = new_ub_bias .* (1 - flag1) + lower_bound_bias .* flag1;
        flag2         = b2 > upper_bound_bias;
        b2            = b2 .* (1 - flag2) + new_ub_bias .* flag2;

        % Binomial crossover is not used to generate the trial vector under this condition
        u{1, 1} = w2;
        u{1, 2} = b2;
        u{1, 3} = 0;
    case 3
        %**************************"rand/2/bin" strategy**************************%
        % Choose the indices for mutation
        indexSet    = 1 : popsize;
        indexSet(i) = [];

        % Choose the first index
        temp           = floor(rand * (popsize - 1)) + 1;
        index(1)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the second index
        temp           = floor(rand * (popsize - 2)) + 1;
        index(2)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the third index
        temp           = floor(rand * (popsize - 3)) + 1;
        index(3)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the fourth index
        temp           = floor(rand * (popsize - 4)) + 1;
        index(4)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the fifth index
        temp           = floor(rand * (popsize - 5)) + 1;
        index(5)       = indexSet(temp);

        % Mutation (weight)
        w3 = parent_struct{1, index(1)}{1, 1} + rand .* (parent_struct{1, index(2)}{1, 1} - parent_struct{1, index(3)}{1, 1}) + F .* (parent_struct{1, index(4)}{1, 1} - parent_struct{1, index(5)}{1, 1});

        % Mutation (bias)
        b3 = parent_struct{1, index(1)}{1, 2} + rand .* (parent_struct{1, index(2)}{1, 2} - parent_struct{1, index(3)}{1, 2}) + F .* (parent_struct{1, index(4)}{1, 2} - parent_struct{1, index(5)}{1, 2});

        % Handling out of boundary for weight
        new_lb_weight = 2 .* lower_bound_weight - w3;
        flag1         = new_lb_weight > upper_bound_weight;
        new_lb_weight = new_lb_weight .* (1 - flag1) + upper_bound_weight .* flag1;
        flag2         = w3 < lower_bound_weight;
        w3            = w3 .* (1 - flag2) + new_lb_weight .* flag2;

        new_ub_weight = 2 .* upper_bound_weight - w3;
        flag1         = new_ub_weight < lower_bound_weight;
        new_ub_weight = new_ub_weight .* (1 - flag1) + lower_bound_weight .* flag1;
        flag2         = w3 > upper_bound_weight;
        w3            = w3 .* (1 - flag2) + new_ub_weight .* flag2;

        % Handling out of boundary for bias
        new_lb_bias   = 2 .* lower_bound_bias - b3;
        flag1         = new_lb_bias > upper_bound_bias;
        new_lb_bias   = new_lb_bias .* (1 - flag1) + upper_bound_bias .* flag1;
        flag2         = b3 < lower_bound_bias;
        b3            = b3 .* (1 - flag2) + new_lb_bias .* flag2;

        new_ub_bias   = 2 .* upper_bound_bias - b3;
        flag1         = new_ub_bias < lower_bound_bias;
        new_ub_bias   = new_ub_bias .* (1 - flag1) + lower_bound_bias .* flag1;
        flag2         = b3 > upper_bound_bias;
        b3            = b3 .* (1 - flag2) + new_ub_bias .* flag2;

        % Binomial crossover (weight)
        j_rand                     = rand(size(w3));
        row_index                  = floor(rand * size(w3, 1)) + 1;
        col_index                  = floor(rand * size(w3, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        w3                         = w3 .* flag + parent_struct{1, i}{1, 1} .* (1 - flag);

        % Binomial crossover (bias)
        j_rand                     = rand(size(b3));
        row_index                  = floor(rand * size(b3, 1)) + 1;
        col_index                  = floor(rand * size(b3, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        b3                         = b3 .* flag + parent_struct{1, i}{1, 2} .* (1 - flag);

        u{1, 1} = w3;
        u{1, 2} = b3;
        u{1, 3} = 0;    
    case 4
        %**************************"best/1/bin" strategy**************************%
        
        % Choose the indices for mutation
        indexSet       = 1 : popsize;
        indexSet(i)    = [];

        % Choose the first Index
        temp           = floor(rand * (popsize - 1)) + 1;
        index(1)       = indexSet(temp);
        indexSet(temp) = [];

        % Choose the second index
        temp           = floor(rand * (popsize - 2)) + 1;
        index(2)       = indexSet(temp);
        
        w4 = bestSolution{1, 1} + F .* (parent_struct{1, index(1)}{1, 1} - parent_struct{1, index(2)}{1, 1});
        
        b4 = bestSolution{1, 2} + F .* (parent_struct{1, index(1)}{1, 2} - parent_struct{1, index(2)}{1, 2});
        
        % Handling out of boundary for weight
        new_lb_weight = 2 .* lower_bound_weight - w4;
        flag1         = new_lb_weight > upper_bound_weight;
        new_lb_weight = new_lb_weight .* (1 - flag1) + upper_bound_weight .* flag1;
        flag2         = w4 < lower_bound_weight;
        w4            = w4 .* (1 - flag2) + new_lb_weight .* flag2;

        new_ub_weight = 2 .* upper_bound_weight - w4;
        flag1         = new_ub_weight < lower_bound_weight;
        new_ub_weight = new_ub_weight .* (1 - flag1) + lower_bound_weight .* flag1;
        flag2         = w4 > upper_bound_weight;
        w4            = w4 .* (1 - flag2) + new_ub_weight .* flag2;

        % Handling out of boundary for bias
        new_lb_bias   = 2 .* lower_bound_bias - b4;
        flag1         = new_lb_bias > upper_bound_bias;
        new_lb_bias   = new_lb_bias .* (1 - flag1) + upper_bound_bias .* flag1;
        flag2         = b4 < lower_bound_bias;
        b4            = b4 .* (1 - flag2) + new_lb_bias .* flag2;

        new_ub_bias   = 2 .* upper_bound_bias - b4;
        flag1         = new_ub_bias < lower_bound_bias;
        new_ub_bias   = new_ub_bias .* (1 - flag1) + lower_bound_bias .* flag1;
        flag2         = b4 > upper_bound_bias;
        b4            = b4 .* (1 - flag2) + new_ub_bias .* flag2;

        % Binomial crossover (weight)
        j_rand                     = rand(size(w4));
        row_index                  = floor(rand * size(w4, 1)) + 1;
        col_index                  = floor(rand * size(w4, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        w4                         = w4 .* flag + parent_struct{1, i}{1, 1} .* (1 - flag);

        % Binomial crossover (bias)
        j_rand                     = rand(size(b4));
        row_index                  = floor(rand * size(b4, 1)) + 1;
        col_index                  = floor(rand * size(b4, 2)) + 1;
        flag                       = j_rand < CR;
        flag(row_index, col_index) = 1;
        b4                         = b4 .* flag + parent_struct{1, i}{1, 2} .* (1 - flag);

        u{1, 1} = w4;
        u{1, 2} = b4;
        u{1, 3} = 0;
end