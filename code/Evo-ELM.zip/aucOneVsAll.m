function output = aucOneVsAll(targets, outputs)

    [row, col] = size(targets);
    auc        = zeros(row, 1);
    ratio      = zeros(row, 1);
    output     = 0;
    
    for i = 1: row
        auc(i, 1)   = aucStatistic(targets(i, :),outputs(i, :)); 
        ratio(i, 1) = sum(targets(i, :)) / col;
        output      = output + auc(i, 1) * ratio(i, 1);
    end
   
%     plotroc(targets,outputs);
%     legend('FontSize',18,'Location','SouthEast');

end