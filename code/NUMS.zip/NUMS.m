% % % %?------------------------------------------------------------------------%
% This script is the main procedure NUMS which adapt the originally
% uniformly distributed references towards the region of interest (ROI).
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (http://www.cs.bham.ac.uk/~likw)
% Last modified: 01/24/2016
% ------------------------------------------------------------------------%

close all
clear
clc

addpath('Projsplx/');
figure;
%% parameter settings
nobjs     = 3;
popsize   = 100;

problems  = 'DTLZ1';
refp_idx  = 1;
propotion = 0.2;
m_type    = 2;      % 1: linear model; 2: exponential model
b_flag    = 2;      % 1: keep the boundary, otherwise remove boundary

if strcmp(problems, 'ZDT1')
    refp_set = [0.3, 0.4; 0.65, 0.3];
elseif strcmp(problems, 'ZDT2')
    refp_set = [0.2, 0.8; 0.9, 0.4];
elseif strcmp(problems, 'ZDT3')
    refp_set = [0.15, 0.4; 0.4, 0.0];
elseif strcmp(problems, 'ZDT4')
    refp_set = [0.3, 0.4; 0.65, 0.3];
elseif strcmp(problems, 'ZDT6')
    refp_set = [0.9, 0.3; 0.5, 0.7];
elseif strcmp(problems, 'WFG41')
    refp_set = [0.75, 1.5; 2.0, 1.0];
elseif strcmp(problems, 'WFG42')
    refp_set = [0.1, 1.0; 1.5, 0.5];
elseif strcmp(problems, 'WFG43')
    refp_set = [1.5, 1.5; 0.5, 2.5];
elseif strcmp(problems, 'WFG44')
    refp_set = [1.5, 0.8; 1.0, 1.4];
elseif strcmp(problems, 'WFG45')
    refp_set = [1.5, 0.5; 1.0, 1.5];
elseif strcmp(problems, 'WFG46')
    refp_set = [1.25, 0.5; 0.8, 1.5];
elseif strcmp(problems, 'WFG47')
    refp_set = [0.5, 1.0; 1.5, 0.5];
elseif strcmp(problems, 'WFG48')
    refp_set = [0.5, 1.5; 1.25, 0.5];
elseif strcmp(problems, 'DTLZ1')
    refp_set = [0.05, 0.05, 0.2; 0.3, 0.3, 0.2];
elseif strcmp(problems, 'DTLZ2')
    refp_set = [0.2, 0.5, 0.6; 0.7, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ3')
    refp_set = [0.2, 0.5, 0.6; 0.7, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ4')
    refp_set = [0.2, 0.5, 0.6; 0.7, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ5')
    refp_set = [0.1, 0.3, 0.5; 0.6, 0.7, 0.5];
elseif strcmp(problems, 'DTLZ6')
    refp_set = [0.1, 0.3, 0.5; 0.6, 0.7, 0.5];
elseif strcmp(problems, 'DTLZ7')
    refp_set = [0.165, 0.71, 4.678; 0.75, 0.15, 6.0; 0.1, 0.1, 4.0];
elseif strcmp(problems, 'DTLZ1_5D')
    refp_set = [0.05, 0.05, 0.1, 0.08, 0.03; 0.2, 0.1, 0.1, 0.3, 0.4];
elseif strcmp(problems, 'DTLZ1_8D')
    refp_set = [0.01, 0.02, 0.07, 0.02, 0.06, 0.2, 0.1, 0.01; 0.1, 0.2, 0.1, 0.4, 0.4, 0.1, 0.3, 0.1];
elseif strcmp(problems, 'DTLZ1_10D')
    refp_set = [0.02, 0.01, 0.06, 0.04, 0.04, 0.01, 0.02, 0.03, 0.05, 0.08; 0.05, 0.1, 0.1, 0.05, 0.1, 0.2, 0.08, 0.03, 0.3, 0.1];
elseif strcmp(problems, 'DTLZ2_5D')
    refp_set = [0.3, 0.1, 0.4, 0.2, 0.3; 0.7, 0.6, 0.3, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ2_8D')
    refp_set = [0.3, 0.1, 0.4, 0.25, 0.1, 0.15, 0.4, 0.25; 0.6, 0.5, 0.75, 0.2, 0.3, 0.55, 0.7, 0.6];
elseif strcmp(problems, 'DTLZ2_10D')
    refp_set = [0.3, 0.3, 0.3, 0.1, 0.3, 0.55, 0.35, 0.35, 0.25, 0.45; 0.1, 0.1, 0.3, 0.4, 0.2, 0.5, 0.25, 0.15, 0.1, 0.4];
end

ref_point = refp_set(refp_idx, :);

%% find the projection of 'ref_point' on the m-simplex
% vote_w = projsplx(ref_point);
vote_w = ref_point ./ sum(ref_point);

%% initialize the template reference points
[w, H]        = initweight(nobjs, popsize);
w             = w';
popsize       = size(w, 1);
transformed_w = zeros(popsize, nobjs);

bound = zeros(popsize, nobjs);  % test

if nobjs > H
    %% if all reference points lie on the boundary
    for i = 1 : popsize
        if sum(abs(vote_w - w(i, :))) == 0
            transformed_w(i, :) = w(i, :);
        else
            t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

            idx = find(t_i > 0);
            [min_value, min_idx] = min(t_i(idx));
            temp = min_value - norm(vote_w - w(i, :));
            t_d = norm(vote_w - w(i, :)) * propotion;
            transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
        end
    end
else
    if m_type == 1
        %% linear model
        for i = 1 : popsize
            if sum(abs(vote_w - w(i, :))) == 0
                transformed_w(i, :) = w(i, :);
            else
                t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

                idx = find(t_i > 0);
                [min_value, min_idx] = min(t_i(idx));
                temp = min_value - norm(vote_w - w(i, :));
                if (temp < 1.0e-04) && (b_flag == 1)
                    t_d = norm(vote_w - w(i, :));
                elseif (temp < 1.0e-04) && (b_flag == 2)
                    t_d = norm(vote_w - w(i, :)) * propotion;
                else
                    t_d = norm(vote_w - w(i, :)) * propotion;
                end
                
                transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
            end
        end
    else
        %% calculate the 'eta' parameter
        eta = eta_calculation(nobjs, H, propotion, b_flag);

        %% reference points transformation
        for i = 1 : popsize
            if sum(abs(vote_w - w(i, :))) < 1.0e-04
                transformed_w(i, :) = w(i, :);
            else        
                t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

                idx = find(t_i > 0);
                [min_value, min_idx] = min(t_i(idx));
                temp = min_value - norm(vote_w - w(i, :));
                if (temp < 1.0e-04) && (b_flag == 1)
                    temp = 0;
                    t_d = min_value - min_value * (temp / min_value)^(1 / (eta + 1));
                    bound(i, :) = w(i, :);
                elseif (temp < 1.0e-04) && (b_flag == 2)
                    t_d = norm(vote_w - w(i, :)) * propotion;
                else
                    t_d = min_value - min_value * (temp / min_value)^(1 / (eta + 1));
                end
                transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
            end
        end
    end
end
transformed_w = [transformed_w; vote_w];

%------------------------Plot Test------------------------%
% load('FUN0');
% hold on
% box on
% parallelcoords(FUN0, 'Color', 'k', 'LineWidth', 1);
% parallelcoords(ref_point, 'Color', 'r', 'LineWidth', 4.5);
% 
% set(gca, 'FontWeight','demi', 'FontSize', 25, 'LineWidth', 1.5);
% xlabel('Objective Index', 'FontSize', 25, 'FontWeight', 'demi');
% ylabel('Objective Value', 'FontSize', 25, 'FontWeight', 'demi');
% 
% hold off
% 
% set(gcf, 'position', [0 0 1000 800]);
% print('-depsc2', '-r1200', 'FUN.eps');
%------------------------Plot Test------------------------%

%% plot and save the reference points
if nobjs == 2
    plot(transformed_w(:, 1), transformed_w(:, 2), 'rs', ref_point(:, 1), ref_point(:, 2), 'bo', ... 
    w(:, 1), w(:, 2), 'g.');
elseif nobjs == 3
    plot3(transformed_w(:, 1), transformed_w(:, 2), transformed_w(:, 3), 'ro', ref_point(:, 1), ref_point(:, 2), ref_point(:, 3), 'bs', ...
    vote_w(:, 1), vote_w(:, 2), vote_w(:, 3), 'go', w(:, 1), w(:, 2), w(:, 3), 'k.');
else
    hold on
    box on
    parallelcoords(transformed_w, 'Color', 'k', 'LineWidth', 1);
    parallelcoords(ref_point, 'Color', 'r', 'LineWidth', 4.5);
%     parallelcoords(vote_w, 'Color', 'g');

    set(gca, 'FontWeight','demi', 'FontSize', 25, 'LineWidth', 1.5);
    xlabel('Objective Index', 'FontSize', 25, 'FontWeight', 'demi');
    ylabel('Objective Value', 'FontSize', 25, 'FontWeight', 'demi');
    
    hold off
    
%     set(gcf, 'position', [0 0 1000 800]);
%     print('-depsc2', '-r1200', 'weight.eps');
end

%------------------------Plot PF------------------------%
% tempW = transformed_w .* transformed_w;
% denominator = sum(tempW, 2);
% deMatrix = denominator(:, ones(nobjs, 1));
% 
% P = transformed_w ./ sqrt(deMatrix);
% 
% hold on
% box on
% 
% parallelcoords(P, 'Color', 'k', 'LineWidth', 1);
% parallelcoords(ref_point, 'Color', 'r', 'LineWidth', 4.5);
% %     parallelcoords(vote_w, 'Color', 'g');
% 
% set(gca, 'FontWeight','demi', 'FontSize', 25, 'LineWidth', 1.5);
% xlabel('Objective Index', 'FontSize', 25, 'FontWeight', 'demi');
% ylabel('Objective Value', 'FontSize', 25, 'FontWeight', 'demi');
% 
% hold off
% 
% set(gcf, 'position', [0 0 1000 800]);
% print('-depsc2', '-r1200', 'PF.eps');
%------------------------Plot PF------------------------%

fpt = fopen(['pW', int2str(nobjs), 'D_', problems, '_', int2str(refp_idx), '.dat'], 'wt');
for i = 1 : size(transformed_w, 1)
    for j = 1 : nobjs
        fprintf(fpt, '%f\t', transformed_w(i, j));
    end
    fprintf(fpt, '\n');
end
fclose(fpt);


