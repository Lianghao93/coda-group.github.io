% ------------------------------------------------------------------------%
% This script is a multi-layer version of NUMS for many-objective case.
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (http://www.cs.bham.ac.uk/~likw)
% Last modified: 01/11/2016
% ------------------------------------------------------------------------%


% ------------------------------------------------------------------------%
% This function calculates the corresponding exponent for NUMS. If 'b_flag
% == 1', we keep the boundary; otherwise we also shift the boundary
% reference points.
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (http://www.cs.bham.ac.uk/~likw)
% Last modified: 01/12/2016
% ------------------------------------------------------------------------%

close all
clear
clc

addpath('Projsplx/');

%% parameter settings
nobjs     = 10;
popsize   = 660;

problems   = 'DTLZ2_10D';
refp_idx   = 2;
proportion = 0.2;
extend     = 0.2;

no_layers  = 3;
layer_size = 220;

if strcmp(problems, 'DTLZ1_5D')
    refp_set = [0.05, 0.05, 0.1, 0.08, 0.03; 0.2, 0.1, 0.1, 0.3, 0.4];
elseif strcmp(problems, 'DTLZ1_8D')
    refp_set = [0.01, 0.02, 0.07, 0.02, 0.06, 0.2, 0.1, 0.01; 0.1, 0.2, 0.1, 0.4, 0.4, 0.1, 0.3, 0.1];
elseif strcmp(problems, 'DTLZ1_10D')
    refp_set = [0.02, 0.01, 0.06, 0.04, 0.04, 0.01, 0.02, 0.03, 0.05, 0.08; 0.05, 0.1, 0.1, 0.05, 0.1, 0.2, 0.08, 0.03, 0.3, 0.1];
elseif strcmp(problems, 'DTLZ2_5D')
    refp_set = [0.3, 0.1, 0.4, 0.2, 0.3; 0.7, 0.6, 0.3, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ2_8D')
    refp_set = [0.3, 0.1, 0.4, 0.25, 0.1, 0.15, 0.4, 0.25; 0.6, 0.5, 0.75, 0.2, 0.3, 0.55, 0.7, 0.6];
elseif strcmp(problems, 'DTLZ2_10D')
    refp_set = [0.1, 0.1, 0.3, 0.4, 0.2, 0.5, 0.25, 0.15, 0.1, 0.4; 0.3, 0.3, 0.3, 0.1, 0.3, 0.55, 0.35, 0.35, 0.25, 0.45];
%     refp_set = [0.1, 0.1, 0.3, 0.4, 0.2, 0.5, 0.25, 0.15, 0.1, 0.4; 0.3, 0.3, 0.3, 0.1, 0.3, 0.55, 0.35, 0.35, 0.25, 0.45];
end

ref_point = refp_set(refp_idx, :);

proportions = zeros(1, no_layers);
for i = 1 : no_layers
    proportions(i) = proportion / i;
end

%% find the projection of 'ref_point' on the m-simplex
% vote_w = projsplx(ref_point);
vote_w = ref_point ./ sum(ref_point);

%% initialize the template reference points
[w, H] = initweight(nobjs, layer_size);
w = w';
layer_size = size(w, 1);

%% generate the first layer
cur_layer = zeros(layer_size, nobjs);
for i = 1 : layer_size
    if sum(abs(vote_w - w(i, :))) == 0
        cur_layer(i, :) = w(i, :);
    else
        t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

        idx = find(t_i > 0);
        [min_value, min_idx] = min(t_i(idx));
        min_value = extend * min_value;
        temp = min_value - norm(vote_w - w(i, :));
        t_d = norm(vote_w - w(i, :)) * proportions(1);
        cur_layer(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
    end
end
transformed_w = cur_layer;
% transformed_w = w;

%% generate the inside layer
for i = 2 : no_layers
    for j = 1 : layer_size
        if sum(abs(vote_w - w(j, :))) == 0
            cur_layer(j, :) = w(j, :);
        else
            t_i = vote_w * norm(vote_w - w(j, :)) ./ (vote_w - w(j, :));

            idx = find(t_i > 0);
            [min_value, min_idx] = min(t_i(idx));
            temp = min_value - norm(vote_w - w(j, :));
            t_d = norm(vote_w - w(j, :)) * proportions(i);
            cur_layer(j, :) = vote_w + t_d * (w(j, :) - vote_w) / norm(vote_w - w(j, :));
        end
    end
    transformed_w = [transformed_w; cur_layer];
end
transformed_w = [transformed_w; vote_w];

%% plot the results
hold on
box on
parallelcoords(transformed_w, 'Color', 'k', 'LineWidth', 1);
parallelcoords(ref_point, 'Color', 'r', 'LineWidth', 4.5);
%     parallelcoords(vote_w, 'Color', 'g');

set(gca, 'FontWeight','demi', 'FontSize', 25, 'LineWidth', 1.5);
xlabel('Objective Index', 'FontSize', 25, 'FontWeight', 'demi');
ylabel('Objective Value', 'FontSize', 25, 'FontWeight', 'demi');

hold off

set(gcf, 'position', [0 0 1000 800]);
print('-depsc2', '-r1200', 'weight.eps');

%------------------------Plot PF------------------------%
tempW = transformed_w .* transformed_w;
denominator = sum(tempW, 2);
deMatrix = denominator(:, ones(nobjs, 1));

P = transformed_w ./ sqrt(deMatrix);

hold on
box on

parallelcoords(P, 'Color', 'k', 'LineWidth', 1);
parallelcoords(ref_point, 'Color', 'r', 'LineWidth', 4.5);
%     parallelcoords(vote_w, 'Color', 'g');

set(gca, 'FontWeight','demi', 'FontSize', 25, 'LineWidth', 1.5);
xlabel('Objective Index', 'FontSize', 25, 'FontWeight', 'demi');
ylabel('Objective Value', 'FontSize', 25, 'FontWeight', 'demi');

hold off

set(gcf, 'position', [0 0 1000 800]);
print('-depsc2', '-r1200', 'PF.eps');
%------------------------Plot PF------------------------%

fpt = fopen(['pW', int2str(nobjs), 'D_', problems, '_', int2str(refp_idx), '.dat'], 'wt');
for i = 1 : size(transformed_w, 1)
    for j = 1 : nobjs
        fprintf(fpt, '%f\t', transformed_w(i, j));
    end
    fprintf(fpt, '\n');
end
fclose(fpt);


