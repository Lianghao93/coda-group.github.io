% ------------------------------------------------------------------------%
% This function calculates the corresponding exponent for NUMS. If
% 'b_flag = 1', the boundary will be kept; otherwise, the boudnary should
% also be shifted.
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (http://www.cs.bham.ac.uk/~likw)
% Last modified: 01/13/2016
% ------------------------------------------------------------------------%

function eta = eta_calculation(nobjs, H, propotion, b_flag)
    
    if b_flag == 1
        denominator = 1 - propotion;
        numerator   = nobjs / H;
    else
        denominator = 1 - (1 - nobjs / H) * propotion;
        numerator   = nobjs / H;
    end

    eta = (log(numerator) / log(denominator)) - 1;    
end