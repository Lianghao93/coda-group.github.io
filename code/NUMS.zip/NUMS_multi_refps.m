% ------------------------------------------------------------------------%
% This script is the main procedure NUMS which adapt the originally
% uniformly distributed references towards the region of interest (ROI).
%
% Author:  Dr. Ke Li @ University of Birmingham
% Contact: keli.genius@gmail.com (http://www.cs.bham.ac.uk/~likw)
% Last modified: 01/13/2016
% ------------------------------------------------------------------------%

close all
clear
clc

addpath('Projsplx/');

%% parameter settings
nobjs     = 3;
popsize   = 91;

problems  = 'DTLZ2';
refp_idx  = 1;
propotion = 0.2;
m_type    = 2;      % 1: linear model; 2: exponential model
b_flag    = 1;      % 1: keep the boundary, otherwise remove boundary
v_flag    = 1;      % 1: pivot vector is not included

if strcmp(problems, 'ZDT1')
    refp_set = [0.3, 0.4; 0.65, 0.3];
elseif strcmp(problems, 'ZDT2')
    refp_set = [0.2, 0.8; 0.9, 0.4];
elseif strcmp(problems, 'ZDT3');
    refp_set = [0.15, 0.4; 0.4, 0.0];
elseif strcmp(problems, 'ZDT4')
    refp_set = [0.3, 0.4; 0.65, 0.3];
elseif strcmp(problems, 'ZDT6')
    refp_set = [0.9, 0.3; 0.5, 0.7];
elseif strcmp(problems, 'DTLZ1')
    refp_set = [0.05, 0.05, 0.2; 0.3, 0.3, 0.2];
elseif strcmp(problems, 'DTLZ2')
    refp_set = [0.2, 0.5, 0.7; 0.9, 0.3, 0.3];
elseif strcmp(problems, 'DTLZ3')
    refp_set = [0.2, 0.5, 0.6; 0.7, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ4')
    refp_set = [0.2, 0.5, 0.6; 0.7, 0.8, 0.5];
elseif strcmp(problems, 'DTLZ5')
    refp_set = [0.1, 0.3, 0.5; 0.6, 0.7, 0.5];
elseif strcmp(problems, 'DTLZ6')
    refp_set = [0.1, 0.3, 0.5; 0.6, 0.7, 0.5];
elseif strcmp(problems, 'DTLZ7')
    refp_set = [0.165, 0.71, 4.678; 0.75, 0.15, 6.0; 0.1, 0.1, 4.0];
elseif strcmp(problems, 'DTLZ2_5D')
    refp_set = [0.3, 0.1, 0.4, 0.2, 0.3];
elseif strcmp(problems, 'DTLZ2_10D')
    refp_set = [0.3, 0.3, 0.3, 0.1, 0.3, 0.55, 0.35, 0.35, 0.25, 0.45];
end

ref_point = refp_set(refp_idx, :);

%% find the projection of 'ref_point' on the m-simplex
vote_w = projsplx(ref_point);

%% initialize the template reference points
[w, H]        = initweight(nobjs, popsize);
w             = w';
popsize       = size(w, 1);
transformed_w = zeros(popsize, nobjs);

if nobjs > H
    %% if all reference points lie on the boundary
    for i = 1 : popsize
        if sum(abs(vote_w - w(i, :))) == 0
            transformed_w(i, :) = w(i, :);
            v_flag = 2;
        else
            t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

            idx = find(t_i > 0);
            [min_value, min_idx] = min(t_i(idx));
            temp = min_value - norm(vote_w - w(i, :));
            t_d = norm(vote_w - w(i, :)) * propotion;
            transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
        end
    end
else
    if m_type == 1
        %% linear model
        for i = 1 : popsize
            if sum(abs(vote_w - w(i, :))) == 0
                transformed_w(i, :) = w(i, :);
                v_flag = 2;
            else
                t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

                idx = find(t_i > 0);
                [min_value, min_idx] = min(t_i(idx));
                temp = min_value - norm(vote_w - w(i, :));
                if (temp < 1.0e-04) && (b_flag == 1)
                    t_d = norm(vote_w - w(i, :));
                elseif (temp < 1.0e-04) && (b_flag == 2)
                    t_d = norm(vote_w - w(i, :)) * propotion;
                else
                    t_d = norm(vote_w - w(i, :)) * propotion;
                end
                
                transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
            end
        end
    else
        %% calculate the 'eta' parameter
        eta = eta_calculation(nobjs, H, propotion, b_flag);

        %% reference points transformation
        for i = 1 : popsize
            if sum(abs(vote_w - w(i, :))) == 0
                transformed_w(i, :) = w(i, :);
                v_flag = 2;
            else        
                t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

                idx = find(t_i > 0);
                [min_value, min_idx] = min(t_i(idx));
                temp = min_value - norm(vote_w - w(i, :));
                if (temp < 0.001) && (b_flag == 1)
                    temp = 0;
                    t_d = min_value - min_value * (temp / min_value)^(1 / (eta + 1));
                elseif (temp < 0.00001) && (b_flag == 2)
                    t_d = norm(vote_w - w(i, :)) * propotion;
                else
                    t_d = min_value - min_value * (temp / min_value)^(1 / (eta + 1));
                end
                transformed_w(i, :) = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
            end
        end
    end
end
if v_flag == 1
    transformed_w = [transformed_w; vote_w];
end

%% find the projection of 'ref_point' on the m-simplex
refp_idx       = 2;
ref_point      = refp_set(refp_idx, :);
vote_w         = projsplx(ref_point);
transformed_w2 = zeros(1, nobjs);
for i = 1 : popsize
    if sum(abs(vote_w - w(i, :))) == 0
        transformed_w2(i, :) = w(i, :);
        v_flag = 2;
    else        
        t_i = vote_w * norm(vote_w - w(i, :)) ./ (vote_w - w(i, :));

        idx = find(t_i > 0);
        [min_value, min_idx] = min(t_i(idx));
        temp = min_value - norm(vote_w - w(i, :));
        if temp < 1.0e-03
            continue;
        else
            t_d = min_value - min_value * (temp / min_value)^(1 / (eta + 1));
            transformed_w2 = vote_w + t_d * (w(i, :) - vote_w) / norm(vote_w - w(i, :));
            transformed_w  = [transformed_w; transformed_w2];
        end
    end
end
if v_flag == 1
    transformed_w = [transformed_w; vote_w];
end


%% plot and save the reference points
if nobjs == 2
    plot(transformed_w(:, 1), transformed_w(:, 2), 'rs', ref_point(:, 1), ref_point(:, 2), 'bo', ... 
    w(:, 1), w(:, 2), 'g.');
elseif nobjs == 3
    plot3(transformed_w(:, 1), transformed_w(:, 2), transformed_w(:, 3), 'ro', ref_point(:, 1), ref_point(:, 2), ref_point(:, 3), 'bs', ...
    vote_w(:, 1), vote_w(:, 2), vote_w(:, 3), 'go', w(:, 1), w(:, 2), w(:, 3), 'k.');
else
    hold on
    parallelcoords(transformed_w);
    parallelcoords(ref_point, 'Color', 'r');
    parallelcoords(vote_w, 'Color', 'g');
    hold off
end

fpt = fopen(['pW', int2str(nobjs), 'D_', problems, '_', int2str(refp_idx), '.dat'], 'wt');
for i = 1 : size(transformed_w, 1)
    for j = 1 : nobjs
        fprintf(fpt, '%f\t', transformed_w(i, j));
    end
    fprintf(fpt, '\n');
end
fclose(fpt);


