function [offspring, objs] = evolve(parent_pop, mop, mating_neighbour, params)
    % This function used to generate the offspring population
    %
    % parent_pop -> the parent population
    % mop        -> the structure of the MOP
    % params     -> the structure of the parameters
    %
    % offspring  -> the offspring population
    % objs       -> the objective values of the offspring population

    objs      = zeros(params.popsize, mop.od);
    offspring = zeros(params.popsize, mop.pd);
    
    for i = 1 : length(parent_pop)        
        if (rand < params.delta)
            matingindex = mating_neighbour(i, :);
        else
            matingindex = (1 : params.popsize);
        end
            
        % new point generation using genetic operations, and evaluate it.
        offspring(i, :) = genetic_op(parent_pop, i, mop.domain, params, matingindex);
        objs(i, :)      = mop.func(offspring(i, :));
    end
end