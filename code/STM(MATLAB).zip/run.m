%**************************************************************************************************
% Author: Ke Li (keli.genius@gmail.com) :: www.cs.cityu.edu.hk/~51888309
% Reference: Ke Li, Qingfu Zhang, Sam Kwong, Miqing Li, Ran Wang, "Stable matching based selection 
%            in evolutionary multiobjective optimization", IEEE  Transactions on Evolutionary 
%            Computation, accepted, 2013.
% Copyright 2013: City University of Hong Kong.
%**************************************************************************************************

clc;
clear;
tic;

format long;
format compact;

problems = {'zdt1'};

problem_length = length(problems);
totalrun       = 1;
dim            = 30;
nobj           = 2;

for i = 1 : problem_length
    problem = problems{i};
    fprintf('Running on %s...\n', problem);
    for j = 1 : totalrun
        mop    = testmop(problem, dim, nobj);
        pareto = smmoead(mop);
        
        eval(['save pareto_' sprintf(problems{i}) '_' num2str(j) ' pareto']);
    end
end

toc;