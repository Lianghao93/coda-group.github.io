function parent_pop = randompoint(mop, popsize)
    % This function initializes the parent population
    %
    % mop        : The structure of the current MOP
    % popsize    : The population size of the paretn population
    %
    % parent_pop : The initialized parent population

    randarray  = rand(popsize, mop.pd);
    lowend     = mop.domain(1, :);
    span       = mop.domain(2, :) - lowend;
    parent_pop = randarray .* (span(ones(1, popsize), :)) + lowend(ones(1, popsize), :);
end
