function pareto = smmoead(mop, varargin)

    starttime = clock;
    % Global variable definition.
    global params idealpoint objDim parDim itrCounter;
    
    % Initialization and set the algorithms parameters.
    paramIn = varargin;
    [objDim, parDim, idealpoint, params, parent_pop, parent_objs, subproblems, mating_neighbour] = init(mop, paramIn);
    
    
    itrCounter = 1;
    num_eval   = 0;
    while ~terminate(num_eval)
        
        % Reproduction
        [offspring, offspring_objs] = evolve(parent_pop, mop, mating_neighbour, params);
        
        % Merge
        mixed_pop  = [parent_pop; offspring];
        mixed_objs = [parent_objs; offspring_objs];
        
        % Update the ideal point
        idealpoint = min(idealpoint, min(mixed_objs));
        
        % Enviromental Selection (Stable Matching)
        [parent_pop, parent_objs] = selection(mixed_pop, mixed_objs, subproblems, params, idealpoint, mop);
        
        % fprintf('iteration %d finished...\n', itrCounter);
        num_eval = num_eval + params.popsize;
        fprintf('evaluation %d finished...\n', num_eval);
        
    end
    
    pareto = mop.func(parent_pop);
    if mop.od == 2
        plot(pareto(:, 1), pareto(:, 2), 'o');
    else
        plot3(pareto(:, 1), pareto(:, 2), pareto(:, 3), 'o');
    end
    
end

function y = terminate(num_eval)

    global params;
    % y = itrcounter > params.iteration;
    y = num_eval > params.evaluation;
    
end